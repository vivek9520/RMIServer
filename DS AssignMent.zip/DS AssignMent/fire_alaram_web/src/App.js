import React from 'react';
import './App.css';
import DashBoard from "./Compenents/DashBoard";

function App() {
  return (
    <div>
      <DashBoard/>
    </div>
  );
}

export default App;
